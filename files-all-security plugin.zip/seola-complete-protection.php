<?php
/**
 * Plugin Name:  SEO.LA Complete Protection
 * Plugin URI:   https://seo.la
 * Description:  All-in-one WordPress security for SEO.LA managed sites. IP Guard, XML-RPC lockdown, REST API hardening, rogue admin alerts, post flood detection, file-edit disable, and PHP execution block in uploads.
 * Version:      1.0.0
 * Author:       SEO.LA
 * License:      GPL-2.0+
 * Text Domain:  seola-cp
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─────────────────────────────────────────────────────────────
//  CONSTANTS & BOOTSTRAP
// ─────────────────────────────────────────────────────────────

define( 'SEOLA_CP_OPTION',  'seola_cp_settings' );
define( 'SEOLA_CP_VERSION', '1.0.0' );
define( 'SEOLA_CP_FILE',    __FILE__ );

function seola_cp_defaults() {
    return [
        'ip_guard_enabled'     => 1,
        'allowed_ips'          => [],
        'disable_xmlrpc'       => 1,
        'block_rest_users'     => 1,
        'disable_registration' => 0,
        'disable_file_edit'    => 1,
        'block_uploads_php'    => 1,
        'alert_new_admin'      => 1,
        'alert_email'          => '',
        'post_flood_enabled'   => 1,
        'post_flood_threshold' => 10,
    ];
}

function seola_cp_get() {
    static $cache = null;
    if ( $cache === null ) {
        $cache = wp_parse_args( get_option( SEOLA_CP_OPTION, [] ), seola_cp_defaults() );
    }
    return $cache;
}

// ─────────────────────────────────────────────────────────────
//  MODULE 1 — IP Guard (admin login by IP)
// ─────────────────────────────────────────────────────────────

add_filter( 'authenticate', 'seola_cp_ip_guard', 30, 3 );

function seola_cp_ip_guard( $user, $username, $password ) {
    $s = seola_cp_get();
    if ( empty( $s['ip_guard_enabled'] ) || empty( $username ) ) return $user;

    $allowed = $s['allowed_ips'];
    if ( empty( $allowed ) ) return $user;

    $u = get_user_by( 'login', $username ) ?: get_user_by( 'email', $username );
    if ( ! $u || ! in_array( 'administrator', (array) $u->roles, true ) ) return $user;

    $ip = seola_cp_client_ip();
    if ( ! in_array( $ip, $allowed, true ) ) {
        seola_cp_log( 'ip_blocked', "Admin login blocked for '{$username}' from IP {$ip}" );
        return new WP_Error(
            'seola_ip_blocked',
            sprintf(
                '<strong>Access Denied.</strong><br>Admin login is not permitted from your current IP: <code>%s</code><br><br>Connect via <strong>SEO.LA VPN (NordLayer)</strong> and try again.',
                esc_html( $ip )
            )
        );
    }
    return $user;
}

// ─────────────────────────────────────────────────────────────
//  MODULE 2 — Disable XML-RPC
// ─────────────────────────────────────────────────────────────

add_filter( 'xmlrpc_enabled', 'seola_cp_xmlrpc' );
add_filter( 'xmlrpc_methods', 'seola_cp_xmlrpc_methods' );
add_action( 'init',           'seola_cp_xmlrpc_block_early' );

function seola_cp_xmlrpc( $enabled ) {
    $s = seola_cp_get();
    return empty( $s['disable_xmlrpc'] ) ? $enabled : false;
}

function seola_cp_xmlrpc_methods( $methods ) {
    $s = seola_cp_get();
    return empty( $s['disable_xmlrpc'] ) ? $methods : [];
}

function seola_cp_xmlrpc_block_early() {
    $s = seola_cp_get();
    if ( empty( $s['disable_xmlrpc'] ) ) return;
    if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
        header( 'HTTP/1.1 403 Forbidden' );
        die( 'XML-RPC is disabled on this site.' );
    }
}

// ─────────────────────────────────────────────────────────────
//  MODULE 3 — REST API hardening (block /users endpoint)
// ─────────────────────────────────────────────────────────────

add_filter( 'rest_endpoints', 'seola_cp_rest_users' );

function seola_cp_rest_users( $endpoints ) {
    $s = seola_cp_get();
    if ( empty( $s['block_rest_users'] ) ) return $endpoints;

    // Remove unauthenticated user enumeration
    $to_remove = [ '/wp/v2/users', '/wp/v2/users/(?P<id>[\d]+)' ];
    foreach ( $to_remove as $route ) {
        if ( isset( $endpoints[ $route ] ) && ! is_user_logged_in() ) {
            unset( $endpoints[ $route ] );
        }
    }
    return $endpoints;
}

// ─────────────────────────────────────────────────────────────
//  MODULE 4 — Disable user self-registration
// ─────────────────────────────────────────────────────────────

add_action( 'init', 'seola_cp_disable_registration' );

function seola_cp_disable_registration() {
    $s = seola_cp_get();
    if ( empty( $s['disable_registration'] ) ) return;
    // Override DB option at runtime — no DB writes needed
    add_filter( 'option_users_can_register', '__return_zero' );
}

// ─────────────────────────────────────────────────────────────
//  MODULE 5 — Alert on new admin user creation
// ─────────────────────────────────────────────────────────────

add_action( 'user_register',   'seola_cp_alert_new_admin' );
add_action( 'set_user_role',   'seola_cp_alert_role_change', 10, 3 );

function seola_cp_alert_new_admin( $user_id ) {
    $s = seola_cp_get();
    if ( empty( $s['alert_new_admin'] ) ) return;

    $user = get_userdata( $user_id );
    if ( ! $user || ! in_array( 'administrator', (array) $user->roles, true ) ) return;

    seola_cp_send_alert(
        '🚨 New Admin User Created — ' . get_bloginfo( 'name' ),
        [
            'Username' => $user->user_login,
            'Email'    => $user->user_email,
            'IP'       => seola_cp_client_ip(),
            'Time'     => current_time( 'Y-m-d H:i:s' ),
            'Site'     => get_site_url(),
        ],
        'A new administrator account was just created on your site. If this was not you, log in immediately and delete this user.'
    );

    seola_cp_log( 'new_admin', "New admin created: {$user->user_login} ({$user->user_email}) from IP " . seola_cp_client_ip() );
}

function seola_cp_alert_role_change( $user_id, $new_role, $old_roles ) {
    $s = seola_cp_get();
    if ( empty( $s['alert_new_admin'] ) || $new_role !== 'administrator' ) return;
    if ( in_array( 'administrator', (array) $old_roles, true ) ) return; // already was admin

    $user = get_userdata( $user_id );
    seola_cp_send_alert(
        '🚨 User Elevated to Admin — ' . get_bloginfo( 'name' ),
        [
            'Username'  => $user->user_login,
            'Email'     => $user->user_email,
            'Old Roles' => implode( ', ', $old_roles ) ?: 'none',
            'IP'        => seola_cp_client_ip(),
            'Time'      => current_time( 'Y-m-d H:i:s' ),
            'Site'      => get_site_url(),
        ],
        'An existing user was just promoted to Administrator. If this was not you, log in immediately and review user roles.'
    );
}

// ─────────────────────────────────────────────────────────────
//  MODULE 6 — Post flood detection
// ─────────────────────────────────────────────────────────────

add_action( 'publish_post', 'seola_cp_post_flood_check' );

function seola_cp_post_flood_check( $post_id ) {
    $s = seola_cp_get();
    if ( empty( $s['post_flood_enabled'] ) ) return;

    $threshold = max( 1, (int) $s['post_flood_threshold'] );
    $count     = (int) get_transient( 'seola_cp_post_count' );
    $count++;
    set_transient( 'seola_cp_post_count', $count, HOUR_IN_SECONDS );

    if ( $count >= $threshold && ! get_transient( 'seola_cp_flood_alerted' ) ) {
        seola_cp_send_alert(
            '🚨 Post Flood Detected — ' . get_bloginfo( 'name' ),
            [
                'Posts in last hour' => $count,
                'Threshold'          => $threshold,
                'Latest post ID'     => $post_id,
                'Time'               => current_time( 'Y-m-d H:i:s' ),
                'Site'               => get_site_url(),
            ],
            "More than {$threshold} posts were published in the last hour. This may indicate automated spam injection. Check your WordPress admin immediately."
        );
        set_transient( 'seola_cp_flood_alerted', 1, HOUR_IN_SECONDS );
        seola_cp_log( 'post_flood', "Post flood: {$count} posts in 1hr (threshold: {$threshold})" );
    }
}

// ─────────────────────────────────────────────────────────────
//  MODULE 7 — Disable theme/plugin file editor
// ─────────────────────────────────────────────────────────────

add_action( 'init', 'seola_cp_disable_file_edit' );

function seola_cp_disable_file_edit() {
    $s = seola_cp_get();
    if ( empty( $s['disable_file_edit'] ) ) return;
    if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
        define( 'DISALLOW_FILE_EDIT', true );
    }
}

// ─────────────────────────────────────────────────────────────
//  MODULE 8 — Block PHP execution in /uploads/
// ─────────────────────────────────────────────────────────────

function seola_cp_write_uploads_htaccess( $enable ) {
    if ( ! function_exists( 'insert_with_markers' ) ) {
        require_once ABSPATH . 'wp-admin/includes/misc.php';
    }
    $upload_dir = wp_upload_dir();
    $htaccess   = trailingslashit( $upload_dir['basedir'] ) . '.htaccess';
    $rules = $enable ? [
        '<FilesMatch "\.(php|php3|php4|php5|php7|phtml|pl|py|jsp|asp|htm|shtml|sh|cgi)$">',
        '  Order Allow,Deny',
        '  Deny from all',
        '</FilesMatch>',
    ] : [];
    insert_with_markers( $htaccess, 'SEO.LA Complete Protection', $rules );
}

// ─────────────────────────────────────────────────────────────
//  UTILITIES
// ─────────────────────────────────────────────────────────────

function seola_cp_client_ip() {
    foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'REMOTE_ADDR' ] as $h ) {
        if ( ! empty( $_SERVER[ $h ] ) ) {
            $ip = trim( explode( ',', $_SERVER[ $h ] )[0] );
            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
        }
    }
    return '0.0.0.0';
}

function seola_cp_send_alert( $subject, $details, $message ) {
    $s     = seola_cp_get();
    $email = ! empty( $s['alert_email'] ) ? $s['alert_email'] : get_option( 'admin_email' );
    if ( empty( $email ) ) return;

    $body  = $message . "\n\n";
    $body .= str_repeat( '─', 40 ) . "\n";
    foreach ( $details as $label => $value ) {
        $body .= sprintf( "%-20s %s\n", $label . ':', $value );
    }
    $body .= str_repeat( '─', 40 ) . "\n";
    $body .= "\nThis alert was sent by SEO.LA Complete Protection v" . SEOLA_CP_VERSION . "\n" . get_site_url();

    wp_mail( $email, $subject, $body );
}

function seola_cp_log( $event, $message ) {
    $log = get_option( 'seola_cp_log', [] );
    array_unshift( $log, [
        'time'    => current_time( 'Y-m-d H:i:s' ),
        'event'   => $event,
        'message' => $message,
    ] );
    // Keep last 100 entries only
    update_option( 'seola_cp_log', array_slice( $log, 0, 100 ) );
}

// ─────────────────────────────────────────────────────────────
//  ACTIVATION / DEACTIVATION
// ─────────────────────────────────────────────────────────────

register_activation_hook( SEOLA_CP_FILE, 'seola_cp_activate' );
register_deactivation_hook( SEOLA_CP_FILE, 'seola_cp_deactivate' );

function seola_cp_activate() {
    $existing = get_option( SEOLA_CP_OPTION, null );
    if ( $existing === null ) {
        $defaults              = seola_cp_defaults();
        $ip                    = seola_cp_client_ip();
        $defaults['allowed_ips'] = ( filter_var( $ip, FILTER_VALIDATE_IP ) && $ip !== '0.0.0.0' ) ? [ $ip ] : [];
        $defaults['alert_email'] = get_option( 'admin_email', '' );
        update_option( SEOLA_CP_OPTION, $defaults );
    }
    $s = seola_cp_get();
    if ( ! empty( $s['block_uploads_php'] ) ) {
        seola_cp_write_uploads_htaccess( true );
    }
}

function seola_cp_deactivate() {
    // Remove the uploads .htaccess rule on deactivation
    seola_cp_write_uploads_htaccess( false );
}

// ─────────────────────────────────────────────────────────────
//  ADMIN UI — Settings Page
// ─────────────────────────────────────────────────────────────

add_action( 'admin_menu', 'seola_cp_menu' );
add_action( 'admin_init', 'seola_cp_register_settings' );

function seola_cp_menu() {
    add_options_page(
        'SEO.LA Complete Protection',
        '🛡 SEO.LA Protect',
        'manage_options',
        'seola-cp',
        'seola_cp_page'
    );
}

function seola_cp_register_settings() {
    register_setting( SEOLA_CP_OPTION, SEOLA_CP_OPTION, [
        'sanitize_callback' => 'seola_cp_sanitize',
    ] );
}

function seola_cp_sanitize( $in ) {
    $out = seola_cp_defaults();

    // Toggles
    foreach ( [ 'ip_guard_enabled', 'disable_xmlrpc', 'block_rest_users', 'disable_registration',
                'disable_file_edit', 'block_uploads_php', 'alert_new_admin', 'post_flood_enabled' ] as $key ) {
        $out[ $key ] = ! empty( $in[ $key ] ) ? 1 : 0;
    }

    // IP list
    $out['allowed_ips'] = [];
    if ( ! empty( $in['allowed_ips_raw'] ) ) {
        foreach ( preg_split( '/[\r\n]+/', $in['allowed_ips_raw'] ) as $line ) {
            $ip = trim( $line );
            if ( $ip !== '' && filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                $out['allowed_ips'][] = $ip;
            } elseif ( $ip !== '' ) {
                add_settings_error( SEOLA_CP_OPTION, 'bad_ip', "Skipped invalid IP: <code>" . esc_html( $ip ) . "</code>", 'warning' );
            }
        }
        $out['allowed_ips'] = array_values( array_unique( $out['allowed_ips'] ) );
    }

    // Alert email
    $out['alert_email'] = sanitize_email( $in['alert_email'] ?? '' );

    // Post flood threshold
    $out['post_flood_threshold'] = max( 1, (int) ( $in['post_flood_threshold'] ?? 10 ) );

    // Handle uploads .htaccess
    seola_cp_write_uploads_htaccess( ! empty( $out['block_uploads_php'] ) );

    return $out;
}

// ─────────────────────────────────────────────────────────────
//  SETTINGS PAGE RENDER
// ─────────────────────────────────────────────────────────────

function seola_cp_page() {
    $s          = seola_cp_get();
    $current_ip = seola_cp_client_ip();
    $ip_ok      = in_array( $current_ip, $s['allowed_ips'], true );
    $log        = get_option( 'seola_cp_log', [] );

    $modules = [
        [ 'key' => 'ip_guard_enabled',     'icon' => '🔒', 'label' => 'IP Guard',              'desc' => 'Admin login restricted to whitelisted IPs' ],
        [ 'key' => 'disable_xmlrpc',       'icon' => '🔌', 'label' => 'XML-RPC Disabled',       'desc' => 'Blocks the most-abused remote execution endpoint' ],
        [ 'key' => 'block_rest_users',     'icon' => '👥', 'label' => 'REST Users Blocked',     'desc' => 'Hides user list from unauthenticated REST API calls' ],
        [ 'key' => 'disable_registration', 'icon' => '🚫', 'label' => 'Registration Disabled',  'desc' => 'No one can self-register a new account' ],
        [ 'key' => 'disable_file_edit',    'icon' => '✏️',  'label' => 'File Editor Disabled',   'desc' => 'Theme/plugin editors removed from WP admin' ],
        [ 'key' => 'block_uploads_php',    'icon' => '📁', 'label' => 'Uploads PHP Blocked',    'desc' => 'PHP execution denied in /wp-content/uploads/' ],
        [ 'key' => 'alert_new_admin',      'icon' => '📧', 'label' => 'Admin Alert Active',     'desc' => 'Email sent when a new administrator is created' ],
        [ 'key' => 'post_flood_enabled',   'icon' => '🌊', 'label' => 'Flood Detection Active', 'desc' => 'Alerts when post creation exceeds threshold' ],
    ];
    ?>
    <div class="wrap seola-cp-wrap">

        <div class="seola-header">
            <div class="seola-brand">
                <span class="seola-logo">🛡</span>
                <div>
                    <h1>SEO.LA Complete Protection</h1>
                    <span class="seola-version">v<?php echo SEOLA_CP_VERSION; ?></span>
                </div>
            </div>
        </div>

        <?php settings_errors( SEOLA_CP_OPTION ); ?>

        <!-- STATUS GRID -->
        <div class="seola-status-grid">
            <?php foreach ( $modules as $m ) : $active = ! empty( $s[ $m['key'] ] ); ?>
            <div class="seola-card <?php echo $active ? 'active' : 'inactive'; ?>">
                <div class="seola-card-icon"><?php echo $m['icon']; ?></div>
                <div class="seola-card-body">
                    <strong><?php echo esc_html( $m['label'] ); ?></strong>
                    <span><?php echo esc_html( $m['desc'] ); ?></span>
                </div>
                <div class="seola-card-badge"><?php echo $active ? 'ON' : 'OFF'; ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- TABS -->
        <div class="seola-tabs">
            <button class="seola-tab active" data-tab="login">🔒 Login Security</button>
            <button class="seola-tab" data-tab="hardening">🔧 Hardening</button>
            <button class="seola-tab" data-tab="monitoring">📧 Monitoring</button>
            <button class="seola-tab" data-tab="log">📋 Event Log</button>
        </div>

        <form method="post" action="options.php">
            <?php settings_fields( SEOLA_CP_OPTION ); ?>

            <!-- ── TAB: LOGIN SECURITY ─────────────────────── -->
            <div class="seola-tab-panel active" id="tab-login">
                <div class="seola-section">
                    <h2>🔒 IP Guard — Admin Login Protection</h2>
                    <p>Administrators can only log in from the IPs below. All other roles are unaffected.</p>

                    <div class="seola-ip-notice <?php echo $ip_ok ? 'ip-ok' : 'ip-warn'; ?>">
                        <strong>Your current IP:</strong> <code><?php echo esc_html( $current_ip ); ?></code>
                        <?php if ( $ip_ok ) : ?>
                            <span class="badge-ok">✔ Whitelisted</span>
                        <?php else : ?>
                            <span class="badge-warn">✘ Not in list — add it before saving or you'll lock yourself out</span>
                        <?php endif; ?>
                    </div>

                    <table class="form-table">
                        <tr>
                            <th><label>Enable IP Guard</label></th>
                            <td>
                                <label class="seola-toggle">
                                    <input type="checkbox" name="<?php echo SEOLA_CP_OPTION; ?>[ip_guard_enabled]" value="1" <?php checked( $s['ip_guard_enabled'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="seola_ips">Whitelisted IPs</label></th>
                            <td>
                                <textarea id="seola_ips" name="<?php echo SEOLA_CP_OPTION; ?>[allowed_ips_raw]"
                                    rows="8" cols="30" class="large-text code"
                                    placeholder="One IP per line&#10;e.g. 203.0.113.55"
                                    spellcheck="false"><?php echo esc_textarea( implode( "\n", $s['allowed_ips'] ) ); ?></textarea>
                                <p class="description">One IPv4 or IPv6 per line. Invalid entries are skipped with a warning.</p>
                                <button type="button" class="button seola-add-ip" data-ip="<?php echo esc_attr( $current_ip ); ?>" data-target="seola_ips">
                                    + Add my current IP (<?php echo esc_html( $current_ip ); ?>)
                                </button>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- ── TAB: HARDENING ─────────────────────────── -->
            <div class="seola-tab-panel" id="tab-hardening">
                <div class="seola-section">
                    <h2>🔧 Attack Surface Reduction</h2>
                    <p>Eliminate the most common entry points and remote-execution vectors.</p>

                    <table class="form-table">
                        <tr>
                            <th>Disable XML-RPC</th>
                            <td>
                                <label class="seola-toggle">
                                    <input type="checkbox" name="<?php echo SEOLA_CP_OPTION; ?>[disable_xmlrpc]" value="1" <?php checked( $s['disable_xmlrpc'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description">Blocks <code>xmlrpc.php</code> — the most-abused WordPress endpoint. Safe to disable unless you use the WP mobile app or Jetpack.</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Block REST API User List</th>
                            <td>
                                <label class="seola-toggle">
                                    <input type="checkbox" name="<?php echo SEOLA_CP_OPTION; ?>[block_rest_users]" value="1" <?php checked( $s['block_rest_users'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description">Hides <code>/wp-json/wp/v2/users</code> from unauthenticated requests. Prevents username enumeration via REST API.</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Disable User Self-Registration</th>
                            <td>
                                <label class="seola-toggle">
                                    <input type="checkbox" name="<?php echo SEOLA_CP_OPTION; ?>[disable_registration]" value="1" <?php checked( $s['disable_registration'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description">Overrides Settings → General → "Anyone can register". Locks registration completely.</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Disable Theme/Plugin File Editor</th>
                            <td>
                                <label class="seola-toggle">
                                    <input type="checkbox" name="<?php echo SEOLA_CP_OPTION; ?>[disable_file_edit]" value="1" <?php checked( $s['disable_file_edit'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description">Sets <code>DISALLOW_FILE_EDIT</code>. Removes Appearance → Theme Editor and Plugins → Plugin Editor — so even a compromised admin account can't inject code via the browser.</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Block PHP in Uploads Folder</th>
                            <td>
                                <label class="seola-toggle">
                                    <input type="checkbox" name="<?php echo SEOLA_CP_OPTION; ?>[block_uploads_php]" value="1" <?php checked( $s['block_uploads_php'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description">Writes an <code>.htaccess</code> rule to <code>/wp-content/uploads/</code> denying execution of <code>.php</code>, <code>.phtml</code>, <code>.pl</code>, <code>.asp</code>, and similar files. Kills the most common backdoor drop point. <strong>Apache only.</strong></p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- ── TAB: MONITORING ────────────────────────── -->
            <div class="seola-tab-panel" id="tab-monitoring">
                <div class="seola-section">
                    <h2>📧 Alerts & Monitoring</h2>
                    <p>Get emailed the moment something suspicious happens — even if you're not logged in.</p>

                    <table class="form-table">
                        <tr>
                            <th><label for="seola_alert_email">Alert Email Address</label></th>
                            <td>
                                <input type="email" id="seola_alert_email"
                                    name="<?php echo SEOLA_CP_OPTION; ?>[alert_email]"
                                    value="<?php echo esc_attr( $s['alert_email'] ); ?>"
                                    class="regular-text"
                                    placeholder="<?php echo esc_attr( get_option('admin_email') ); ?>">
                                <p class="description">All security alerts go here. Defaults to the site admin email if left blank.</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Alert on New Admin User</th>
                            <td>
                                <label class="seola-toggle">
                                    <input type="checkbox" name="<?php echo SEOLA_CP_OPTION; ?>[alert_new_admin]" value="1" <?php checked( $s['alert_new_admin'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description">Sends an immediate email alert when any user is created with the <code>administrator</code> role, or when an existing user is promoted to admin. Includes IP address of the action.</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Post Flood Detection</th>
                            <td>
                                <label class="seola-toggle">
                                    <input type="checkbox" name="<?php echo SEOLA_CP_OPTION; ?>[post_flood_enabled]" value="1" <?php checked( $s['post_flood_enabled'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description">Alerts if more than the threshold number of posts are published within one hour. One alert per hour maximum to prevent inbox flooding.</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="seola_flood_threshold">Post Flood Threshold</label></th>
                            <td>
                                <input type="number" id="seola_flood_threshold"
                                    name="<?php echo SEOLA_CP_OPTION; ?>[post_flood_threshold]"
                                    value="<?php echo esc_attr( $s['post_flood_threshold'] ); ?>"
                                    min="1" max="500" style="width:80px;">
                                <span class="description"> posts per hour before an alert is sent.</span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <?php submit_button( 'Save All Settings', 'primary large', 'submit', true, [ 'style' => 'margin-top:0' ] ); ?>
        </form>

        <!-- ── TAB: EVENT LOG ──────────────────────────── -->
        <div class="seola-tab-panel" id="tab-log">
            <div class="seola-section">
                <h2>📋 Event Log <span style="font-size:13px;font-weight:400;color:#888;">(last 100 events)</span></h2>
                <?php if ( empty( $log ) ) : ?>
                    <p style="color:#888;">No events recorded yet. The log fills up as the plugin detects activity.</p>
                <?php else : ?>
                    <table class="widefat striped" style="max-width:860px;">
                        <thead><tr><th width="160">Time</th><th width="140">Event</th><th>Detail</th></tr></thead>
                        <tbody>
                            <?php foreach ( $log as $entry ) : ?>
                            <tr>
                                <td><code><?php echo esc_html( $entry['time'] ); ?></code></td>
                                <td><span class="seola-event-badge event-<?php echo esc_attr( $entry['event'] ); ?>"><?php echo esc_html( $entry['event'] ); ?></span></td>
                                <td><?php echo esc_html( $entry['message'] ); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p>
                        <form method="post">
                            <?php wp_nonce_field( 'seola_clear_log' ); ?>
                            <input type="hidden" name="seola_action" value="clear_log">
                            <button type="submit" class="button button-secondary">Clear Log</button>
                        </form>
                    </p>
                <?php endif; ?>
            </div>
        </div>

    </div><!-- .seola-cp-wrap -->

    <?php seola_cp_styles(); ?>
    <?php seola_cp_scripts(); ?>
    <?php
}

// Handle log clear action
add_action( 'admin_init', 'seola_cp_handle_actions' );
function seola_cp_handle_actions() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    if ( isset( $_POST['seola_action'] ) && $_POST['seola_action'] === 'clear_log' ) {
        check_admin_referer( 'seola_clear_log' );
        delete_option( 'seola_cp_log' );
        wp_redirect( add_query_arg( [ 'page' => 'seola-cp', 'tab' => 'log', 'cleared' => 1 ], admin_url( 'options-general.php' ) ) );
        exit;
    }
}

// ─────────────────────────────────────────────────────────────
//  STYLES & SCRIPTS (inline — no extra files)
// ─────────────────────────────────────────────────────────────

function seola_cp_styles() { ?>
<style>
.seola-cp-wrap { max-width: 920px; }
.seola-header { display:flex; align-items:center; justify-content:space-between; margin:20px 0 24px; }
.seola-brand  { display:flex; align-items:center; gap:14px; }
.seola-logo   { font-size:42px; line-height:1; }
.seola-brand h1 { margin:0; font-size:22px; line-height:1.2; }
.seola-version { background:#2271b1; color:#fff; font-size:11px; padding:2px 7px; border-radius:10px; }

/* Status Grid */
.seola-status-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:10px; margin-bottom:28px; }
.seola-card { display:flex; align-items:center; gap:10px; padding:10px 14px; border-radius:6px; border:1px solid #ddd; background:#fafafa; }
.seola-card.active  { border-color:#b7ddb0; background:#f0fff0; }
.seola-card.inactive{ border-color:#e0e0e0; background:#f9f9f9; opacity:.75; }
.seola-card-icon { font-size:22px; flex-shrink:0; }
.seola-card-body { flex:1; min-width:0; }
.seola-card-body strong { display:block; font-size:12px; font-weight:600; }
.seola-card-body span   { font-size:11px; color:#777; line-height:1.3; }
.seola-card-badge { font-size:10px; font-weight:700; padding:2px 7px; border-radius:10px; flex-shrink:0; }
.seola-card.active  .seola-card-badge { background:#1a7f37; color:#fff; }
.seola-card.inactive .seola-card-badge { background:#ccc; color:#555; }

/* Tabs */
.seola-tabs { display:flex; gap:4px; border-bottom:2px solid #2271b1; margin-bottom:0; }
.seola-tab { background:none; border:none; border-radius:6px 6px 0 0; padding:9px 18px; cursor:pointer; font-size:13px; color:#555; border:1px solid transparent; border-bottom:none; }
.seola-tab:hover  { background:#f0f6fc; color:#2271b1; }
.seola-tab.active { background:#fff; border-color:#2271b1; color:#2271b1; font-weight:600; margin-bottom:-2px; }
.seola-tab-panel  { display:none; }
.seola-tab-panel.active { display:block; }

/* Section */
.seola-section { background:#fff; border:1px solid #ddd; border-top:none; border-radius:0 0 6px 6px; padding:24px 28px; margin-bottom:20px; }
.seola-section h2 { margin-top:0; font-size:17px; border-bottom:1px solid #eee; padding-bottom:12px; }

/* IP notice */
.seola-ip-notice { padding:12px 16px; border-radius:5px; margin-bottom:20px; font-size:13px; }
.seola-ip-notice.ip-ok   { background:#f0fff0; border-left:4px solid #1a7f37; }
.seola-ip-notice.ip-warn { background:#fff8f0; border-left:4px solid #d63638; }
.badge-ok   { color:#1a7f37; font-weight:600; margin-left:8px; }
.badge-warn { color:#d63638; font-weight:600; margin-left:8px; }

/* Toggle switch */
.seola-toggle { position:relative; display:inline-block; width:46px; height:24px; vertical-align:middle; margin-right:8px; }
.seola-toggle input { opacity:0; width:0; height:0; }
.seola-toggle .slider { position:absolute; inset:0; background:#ccc; border-radius:24px; cursor:pointer; transition:.25s; }
.seola-toggle .slider:before { content:''; position:absolute; width:18px; height:18px; left:3px; bottom:3px; background:#fff; border-radius:50%; transition:.25s; }
.seola-toggle input:checked + .slider { background:#2271b1; }
.seola-toggle input:checked + .slider:before { transform:translateX(22px); }

/* Event badges */
.seola-event-badge { font-size:11px; padding:2px 8px; border-radius:10px; font-weight:600; display:inline-block; }
.event-ip_blocked  { background:#ffeaea; color:#c0392b; }
.event-new_admin   { background:#fff3e0; color:#e67e22; }
.event-post_flood  { background:#fdebd0; color:#d35400; }

.seola-add-ip { margin-top:8px !important; }
</style>
<?php }

function seola_cp_scripts() { ?>
<script>
// Tab switching
document.querySelectorAll('.seola-tab').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.seola-tab').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.seola-tab-panel').forEach(p => p.classList.remove('active'));
        this.classList.add('active');
        document.getElementById('tab-' + this.dataset.tab).classList.add('active');
    });
});

// Restore active tab from URL param
var params = new URLSearchParams(location.search);
if (params.get('tab')) {
    var t = document.querySelector('[data-tab="' + params.get('tab') + '"]');
    if (t) t.click();
}

// Add current IP button
document.querySelectorAll('.seola-add-ip').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var ip  = this.dataset.ip;
        var ta  = document.getElementById(this.dataset.target);
        var val = ta.value.trim();
        var existing = val ? val.split(/\r?\n/).map(s => s.trim()) : [];
        if (!existing.includes(ip)) {
            ta.value = val ? val + '\n' + ip : ip;
        } else {
            alert(ip + ' is already in the list.');
        }
    });
});
</script>
<?php }

<?php
/**
 * Plugin Name:  SEO.LA IP Guard
 * Plugin URI:   https://seo.la
 * Description:  Restricts WordPress admin login to whitelisted IP addresses only. Non-admin users are never affected. Built for SEO.LA / NordLayer dedicated IP setup.
 * Version:      1.0.0
 * Author:       SEO.LA
 * License:      GPL-2.0+
 * Text Domain:  seola-ip-guard
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SEOLA_IPG_OPTION', 'seola_ip_guard_settings' );
define( 'SEOLA_IPG_VERSION', '1.0.0' );

// ─────────────────────────────────────────────
//  1. CORE: Block admin login by IP
// ─────────────────────────────────────────────

add_filter( 'authenticate', 'seola_ipg_check_login', 30, 3 );

function seola_ipg_check_login( $user, $username, $password ) {

    // Only run when credentials are actually being submitted
    if ( empty( $username ) ) return $user;

    // Resolve user to check their role BEFORE authentication completes
    $user_obj = get_user_by( 'login', $username );
    if ( ! $user_obj ) {
        $user_obj = get_user_by( 'email', $username );
    }

    // Only enforce IP restriction on administrators
    if ( $user_obj && in_array( 'administrator', (array) $user_obj->roles, true ) ) {

        $settings    = get_option( SEOLA_IPG_OPTION, [] );
        $allowed_ips = ! empty( $settings['allowed_ips'] ) ? $settings['allowed_ips'] : [];

        // If no IPs configured yet, skip (fail-open on fresh install)
        if ( empty( $allowed_ips ) ) return $user;

        $client_ip = seola_ipg_get_client_ip();

        if ( ! in_array( $client_ip, $allowed_ips, true ) ) {
            // Return WP_Error — this stops login and shows the message on the login form
            return new WP_Error(
                'seola_ip_blocked',
                sprintf(
                    '<strong>Access Denied.</strong><br>Admin login is not allowed from your IP address: <code>%s</code><br><br>Connect via the <strong>SEO.LA VPN</strong> (NordLayer) and try again.',
                    esc_html( $client_ip )
                )
            );
        }
    }

    return $user;
}

// ─────────────────────────────────────────────
//  2. UTILITY: Reliable client IP detection
// ─────────────────────────────────────────────

function seola_ipg_get_client_ip() {
    // Priority order — stops at first valid public IP
    $headers = [
        'HTTP_CF_CONNECTING_IP',    // Cloudflare
        'HTTP_X_REAL_IP',           // Nginx proxy
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'REMOTE_ADDR',              // Final fallback
    ];

    foreach ( $headers as $header ) {
        if ( ! empty( $_SERVER[ $header ] ) ) {
            // X-Forwarded-For can be a comma-separated list; take the first one
            $ip = trim( explode( ',', $_SERVER[ $header ] )[0] );
            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                return $ip;
            }
        }
    }

    return '0.0.0.0';
}

// ─────────────────────────────────────────────
//  3. ADMIN UI: Settings page under Settings
// ─────────────────────────────────────────────

add_action( 'admin_menu', 'seola_ipg_add_menu' );

function seola_ipg_add_menu() {
    add_options_page(
        'IP Guard Settings',
        '🛡 IP Guard',
        'manage_options',
        'seola-ip-guard',
        'seola_ipg_settings_page'
    );
}

add_action( 'admin_init', 'seola_ipg_register_settings' );

function seola_ipg_register_settings() {
    register_setting( SEOLA_IPG_OPTION, SEOLA_IPG_OPTION, [
        'sanitize_callback' => 'seola_ipg_sanitize_settings',
    ] );
}

function seola_ipg_sanitize_settings( $input ) {
    $sanitized = [];

    if ( ! empty( $input['allowed_ips_raw'] ) ) {
        $lines = preg_split( '/[\r\n]+/', $input['allowed_ips_raw'] );
        $ips   = [];

        foreach ( $lines as $line ) {
            $ip = trim( $line );
            if ( $ip !== '' && filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                $ips[] = $ip;
            } elseif ( $ip !== '' ) {
                add_settings_error(
                    SEOLA_IPG_OPTION,
                    'invalid_ip',
                    sprintf( 'Invalid IP skipped: <code>%s</code>', esc_html( $ip ) ),
                    'warning'
                );
            }
        }

        $sanitized['allowed_ips'] = array_values( array_unique( $ips ) );
    } else {
        $sanitized['allowed_ips'] = [];
    }

    // Preserve proxy mode setting
    $sanitized['trust_proxies'] = ! empty( $input['trust_proxies'] ) ? 1 : 0;

    return $sanitized;
}

function seola_ipg_settings_page() {
    $settings    = get_option( SEOLA_IPG_OPTION, [] );
    $allowed_ips = ! empty( $settings['allowed_ips'] ) ? $settings['allowed_ips'] : [];
    $current_ip  = seola_ipg_get_client_ip();
    $ip_in_list  = in_array( $current_ip, $allowed_ips, true );
    ?>
    <div class="wrap">
        <h1>🛡 SEO.LA IP Guard <span style="font-size:13px;font-weight:400;color:#666;">v<?php echo SEOLA_IPG_VERSION; ?></span></h1>
        <p style="max-width:640px;color:#555;">
            Administrators can only log in from the IP addresses listed below.
            All other user roles (editors, authors, etc.) are <strong>never affected</strong>.
            Typically you'll add your <strong>NordLayer dedicated IP</strong> here once and forget it.
        </p>

        <?php if ( empty( $allowed_ips ) ) : ?>
        <div class="notice notice-warning" style="max-width:640px;">
            <p><strong>⚠ No IPs configured.</strong> The plugin is inactive until you add at least one IP address below.</p>
        </div>
        <?php endif; ?>

        <div style="background:#f0f6fc;border-left:4px solid #2271b1;padding:12px 16px;max-width:640px;margin-bottom:20px;border-radius:0 4px 4px 0;">
            <strong>Your current IP:</strong> <code><?php echo esc_html( $current_ip ); ?></code>
            <?php if ( $ip_in_list ) : ?>
                &nbsp;<span style="color:#1a7f37;font-weight:600;">✔ Whitelisted — you're safe to save.</span>
            <?php else : ?>
                &nbsp;<span style="color:#c0392b;font-weight:600;">✘ Not in the list — add it before saving or you'll lock yourself out!</span>
            <?php endif; ?>
        </div>

        <?php settings_errors( SEOLA_IPG_OPTION ); ?>

        <form method="post" action="options.php" style="max-width:640px;">
            <?php settings_fields( SEOLA_IPG_OPTION ); ?>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">
                        <label for="seola_ips">Whitelisted IPs</label>
                    </th>
                    <td>
                        <textarea
                            id="seola_ips"
                            name="<?php echo esc_attr( SEOLA_IPG_OPTION ); ?>[allowed_ips_raw]"
                            rows="8"
                            cols="30"
                            class="large-text code"
                            placeholder="One IP per line&#10;e.g.&#10;203.0.113.55&#10;198.51.100.12"
                            spellcheck="false"
                        ><?php echo esc_textarea( implode( "\n", $allowed_ips ) ); ?></textarea>
                        <p class="description">One IPv4 or IPv6 address per line. Invalid entries are skipped with a warning.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Quick Add</th>
                    <td>
                        <button type="button" class="button" id="seola_add_current_ip">
                            + Add my current IP (<?php echo esc_html( $current_ip ); ?>)
                        </button>
                        <p class="description">Appends your current IP to the textarea (still need to Save).</p>
                    </td>
                </tr>
            </table>

            <?php submit_button( 'Save Whitelist' ); ?>
        </form>

        <?php if ( ! empty( $allowed_ips ) ) : ?>
        <hr style="max-width:640px;">
        <h2>Active Whitelist (<?php echo count( $allowed_ips ); ?> IP<?php echo count( $allowed_ips ) !== 1 ? 's' : ''; ?>)</h2>
        <table class="widefat striped" style="max-width:420px;">
            <thead>
                <tr><th>IP Address</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ( $allowed_ips as $ip ) : ?>
                <tr>
                    <td><code><?php echo esc_html( $ip ); ?></code></td>
                    <td>
                        <?php if ( $ip === $current_ip ) : ?>
                            <span style="color:#1a7f37;">✔ Your current IP</span>
                        <?php else : ?>
                            <span style="color:#777;">— Whitelisted</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <script>
    document.getElementById('seola_add_current_ip').addEventListener('click', function() {
        var ta  = document.getElementById('seola_ips');
        var ip  = '<?php echo esc_js( $current_ip ); ?>';
        var val = ta.value.trim();
        // Avoid duplicates
        var existing = val.split(/\r?\n/).map(function(s){ return s.trim(); });
        if ( existing.indexOf(ip) === -1 ) {
            ta.value = val ? val + '\n' + ip : ip;
        } else {
            alert('Your IP (' + ip + ') is already in the list.');
        }
    });
    </script>
    <?php
}

// ─────────────────────────────────────────────
//  4. ACTIVATION: Safety check
// ─────────────────────────────────────────────

register_activation_hook( __FILE__, 'seola_ipg_on_activate' );

function seola_ipg_on_activate() {
    // Pre-populate with current admin's IP on first activation so they don't lock themselves out
    $settings = get_option( SEOLA_IPG_OPTION, [] );
    if ( empty( $settings['allowed_ips'] ) ) {
        $current_ip = seola_ipg_get_client_ip();
        if ( filter_var( $current_ip, FILTER_VALIDATE_IP ) && $current_ip !== '0.0.0.0' ) {
            update_option( SEOLA_IPG_OPTION, [
                'allowed_ips' => [ $current_ip ],
            ] );
        }
    }
}
